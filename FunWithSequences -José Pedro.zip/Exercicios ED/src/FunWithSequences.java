
import java.util.Scanner;

/**
 *
 * @author jpedr
 */
public class FunWithSequences {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        int tamanhoA, tamanhoB, tamanhoC, contador = 0;

        tamanhoA = leitor.nextInt();

        int[] vetorA = new int[tamanhoA];

        for (int i = 0; i <= vetorA.length - 1; i++) {
            vetorA[i] = leitor.nextInt();
        }

        tamanhoB = leitor.nextInt();

        int[] vetorB = new int[tamanhoB];

        for (int i = 0; i <= vetorB.length - 1; i++) {
            vetorB[i] = leitor.nextInt();
        }
        
        tamanhoC = tamanhoA;
        
        int[] vetorC = new int[tamanhoC];

        for (int i = 0; i <= vetorA.length - 1; i++) {

            for (int j = 0; j <= vetorB.length - 1; j++) {

                if (vetorA[i] == vetorB[j]) {
                    break;

                } else {
                    if (vetorA[i] != vetorB[j] && j == vetorB.length - 1) {
                        vetorC[contador++] = vetorA[i];
                        break;
                    }
                }
            }
        }
        for(int i = 0; i < contador; i++)
            System.out.println(vetorC[i]);

    }
}
